export const data = {
  boards: [{ _id: "1", name: "My board 1", lists: [{ name: "L1" }] }],
};
